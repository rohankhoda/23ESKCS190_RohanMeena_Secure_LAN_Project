"""Bounded TCP records and the version-one secure-file envelope."""
import os
import re
import struct
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAX_FILE = 8 * 1024 * 1024
BOX_OVERHEAD = 12 + 16

class ProtocolError(ValueError):
    pass

def exact(sock, count):
    data = bytearray()
    while len(data) < count:
        part = sock.recv(min(65536, count - len(data)))
        if not part:
            raise EOFError('incomplete frame')
        data.extend(part)
    return bytes(data)

def send_frame(sock, data):
    sock.sendall(struct.pack('!I', len(data)) + data)

def get_frame(sock, limit):
    size, = struct.unpack('!I', exact(sock, 4))
    if size > limit:
        raise ProtocolError('frame exceeds limit')
    return exact(sock, size)

def valid_name(name):
    if not re.fullmatch(rb'[A-Za-z0-9][A-Za-z0-9._-]{0,79}', name):
        raise ProtocolError('use a simple filename of 1 to 80 ASCII bytes')

def aad(ticket, user, name):
    return b'SLF1' + ticket + bytes([len(user)]) + user + name

def seal(key, ticket, user, name, plain):
    valid_name(name)
    if len(plain) > MAX_FILE:
        raise ProtocolError('file too large')
    nonce = os.urandom(12)
    body = AESGCM(key).encrypt(nonce, plain, aad(ticket, user, name))
    return nonce + body     # body already includes the 16-byte tag

def unseal(key, ticket, user, name, box):
    valid_name(name)
    if not BOX_OVERHEAD <= len(box) <= MAX_FILE + BOX_OVERHEAD:
        raise ProtocolError('invalid envelope length')
    return AESGCM(key).decrypt(box[:12], box[12:], aad(ticket, user, name))
