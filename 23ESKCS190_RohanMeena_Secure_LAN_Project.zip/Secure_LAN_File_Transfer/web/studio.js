'use strict';
const $ = id => document.getElementById(id);
const state = {mode:'sample', file:null, sample:'notes.txt', samples:[], busy:false, receipt:null, url:null, events:[], count:0, limit:8*1024*1024};
const sizeLabel = n => n<1024 ? `${n} B` : n<1048576 ? `${+(n/1024).toFixed(2)} KiB` : `${+(n/1048576).toFixed(2)} MiB`;
function nav(){
  const key=location.hash.slice(1); const view=['workspace','protocol','lan'].includes(key)?key:'workspace';
  document.querySelectorAll('.view').forEach(el => {el.hidden=el.id!==view;});
  document.querySelectorAll('.nav-item').forEach(el => {const active=el.getAttribute('href')==='#'+view;el.classList.toggle('active',active);if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
  window.scrollTo(0,0);
}
window.addEventListener('hashchange',nav);nav();
function announce(s){$('announce').textContent=s;}
function problem(s=''){ $('error').textContent=s;$('error').hidden=!s; }
function controls(){
  $('send').disabled=state.busy || (state.mode==='own'&&!state.file) || (state.mode==='sample'&&!state.samples.length);
  ['deny','tab-sample','tab-own','sample-select','file-box','choose-file'].forEach(id=>$(id).disabled=state.busy);
  document.querySelector('.topology').classList.toggle('is-busy',state.busy);
}
function setMode(mode){
  state.mode=mode;$('sample-box').hidden=mode!=='sample';$('file-box').hidden=mode!=='own';
  $('tab-sample').setAttribute('aria-pressed',mode==='sample');$('tab-own').setAttribute('aria-pressed',mode==='own');
  problem();controls();
}
$('tab-sample').onclick=()=>setMode('sample');$('tab-own').onclick=()=>setMode('own');
function sampleInfo(){const s=state.samples.find(x=>x.name===$('sample-select').value);if(!s)return;state.sample=s.name;$('sample-name').textContent=s.name;$('sample-meta').textContent=`${s.description} · ${sizeLabel(s.size)}`;}
$('sample-select').onchange=sampleInfo;
function useFile(file){
  if(!file)return;
  let fail=''; if(file.size>state.limit)fail='This file is too large. Choose a file of 8 MiB or less.';
  else if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/.test(file.name)) fail='Rename this file using 1–80 ASCII letters, digits, dots, hyphens or underscores. Start with a letter or digit.';
  state.file=fail?null:file; $('own-name').textContent=state.file?file.name:'Choose or drop a file';
  $('own-meta').textContent=state.file?`${sizeLabel(file.size)} · Click to replace`:'Up to 8 MiB · simple ASCII filename';
  problem(fail);controls();
}
$('file-box').onclick=()=>$('choose-file').click(); $('choose-file').onchange=()=>useFile($('choose-file').files[0]);
['dragenter','dragover'].forEach(type=>$('file-box').addEventListener(type,e=>{e.preventDefault();if(!state.busy)$('file-box').classList.add('drag');}));
['dragleave','drop'].forEach(type=>$('file-box').addEventListener(type,e=>{e.preventDefault();$('file-box').classList.remove('drag');if(type==='drop'&&!state.busy)useFile(e.dataTransfer.files[0]);}));
function release(){if(state.url)URL.revokeObjectURL(state.url);state.url=null;state.receipt=null;}
window.addEventListener('pagehide',release);
function badge(type,label){const p=$('receipt-state');p.className=`pill ${type}`;p.textContent=label;}
function logEvent(label,type){
  state.count++;state.events.unshift({label,type,time:new Date()});state.events=state.events.slice(0,6);
  $('events').replaceChildren();for(const e of state.events){const row=document.createElement('div');row.className='event '+e.type;const name=document.createElement('strong');name.textContent=e.label;const t=document.createElement('time');t.dateTime=e.time.toISOString();t.textContent=e.time.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});row.append(name,t);$('events').append(row);}
  $('event-count').textContent=`${String(state.count).padStart(2,'0')} EVENT${state.count===1?'':'S'}`;
}
function resetReceipt(){release();$('empty-receipt').hidden=false;$('denied-receipt').hidden=true;$('success-receipt').hidden=true;$('crypto-fields').hidden=true;$('toggle-fields').setAttribute('aria-expanded','false');$('toggle-fields').lastElementChild.textContent='+';}
function showFields(r){
  $('crypto-fields').replaceChildren();
  const data=[['Transport',r.tls],['Transfer ID',r.ticket],['File envelope',`${r.envelope_bytes} B (input + 28 B)`],['Nonce (hex)',r.nonce],['GCM tag (hex)',r.tag],['Ciphertext prefix',r.cipher_preview||'Empty file: no ciphertext bytes']];
  for(const [key,val] of data){const row=document.createElement('div');row.className='field-row';const label=document.createElement('span');label.textContent=key;const code=document.createElement('code');code.textContent=val;row.append(label,code);$('crypto-fields').append(row);}
}
async function transfer(deny=false){
  if(state.busy)return;
  state.busy=true;controls();problem();resetReceipt();badge('pending',deny?'Checking':'In transit');
  $('empty-receipt').querySelector('strong').textContent=deny?'Checking login…':'Transferring file…';
  $('empty-receipt').querySelector('p').textContent='Waiting for the Python receiver to respond.';
  $('send').querySelector('span').textContent=deny?'Send securely':'Sending…';
  const headers={'X-Lanpost-Action':'transfer-v1','Content-Type':'application/octet-stream'};
  let body=new Uint8Array(0);if(!deny){if(state.mode==='sample')headers['X-Lanpost-Sample']=state.sample;else{headers['X-Lanpost-Name']=state.file.name;body=state.file;}}
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),30000);
  try{
    const response=await fetch(deny?'/api/deny':'/api/transfer',{method:'POST',headers,body,signal:controller.signal});
    const data=await response.json();if(!response.ok||data.error)throw new Error(data.error||'Receiver unavailable.');
    if(deny){if(data.status!=='denied'||data.stored_files!==0)throw new Error('Rejection was not confirmed.');
      $('empty-receipt').hidden=true;$('denied-receipt').hidden=false;badge('denied','Denied');logEvent('Test login denied · No file key issued or file stored','fail');announce('Login denied as expected. No file stored.');
    }else{
      if(data.status!=='verified'||data.sha256!==data.receiver_sha256||data.sha256!==data.receipt_sha256)throw new Error('The returned checksums did not match.');
      const raw=atob(data.recovered_b64); const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
      if(bytes.length!==data.plain_bytes)throw new Error('The received copy has the wrong length.');
      if(globalThis.crypto?.subtle){const h=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));const hex=Array.from(h,x=>x.toString(16).padStart(2,'0')).join('');if(hex!==data.sha256)throw new Error('Browser read-back verification failed.');}
      delete data.recovered_b64;state.receipt=data;state.url=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'}));
      $('r-name').textContent=data.name;$('r-metrics').textContent=`${sizeLabel(data.plain_bytes)} · ${data.elapsed_ms.toFixed(0)} ms`;$('r-digest').textContent=data.sha256;showFields(data);
      $('empty-receipt').hidden=true;$('success-receipt').hidden=false;badge('verified','Verified');
      logEvent(`${data.name} · ${sizeLabel(data.plain_bytes)} received, SHA-256 matched`,'ok');announce('Transfer verified. You can now save the recovered file.');
    }
  }catch(err){
    problem(err.name==='AbortError'?'No receipt arrived before timeout. Delivery is not confirmed.':(err.message||'No storage receipt arrived.'));
    $('empty-receipt').hidden=false;$('empty-receipt').querySelector('strong').textContent='No confirmed receipt';$('empty-receipt').querySelector('p').textContent='Check the message in the dispatch panel and try again.';badge('pending','Unconfirmed');logEvent('Transfer not confirmed · No verified receipt','fail');
  }finally{clearTimeout(timer);state.busy=false;controls();$('send').querySelector('span').textContent='Send securely';}
}
$('send').onclick=()=>transfer(false);$('deny').onclick=()=>transfer(true);
$('save-copy').onclick=()=>{if(state.url&&state.receipt){const a=document.createElement('a');a.href=state.url;a.download=state.receipt.name;document.body.append(a);a.click();a.remove();}};
$('copy-hash').onclick=async()=>{if(!state.receipt)return;try{await navigator.clipboard.writeText(state.receipt.sha256);$('copy-hash').setAttribute('title','Copied');$('copy-hash').querySelector('use').setAttribute('href','#i-check');setTimeout(()=>$('copy-hash').querySelector('use').setAttribute('href','#i-copy'),1600);announce('SHA-256 copied.');}catch{const r=document.createRange();r.selectNodeContents($('r-digest'));const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);announce('Digest selected. Use the system copy command.');}};
$('toggle-fields').onclick=()=>{const opening=$('crypto-fields').hidden;$('crypto-fields').hidden=!opening;$('toggle-fields').lastElementChild.textContent=opening?'−':'+';$('toggle-fields').setAttribute('aria-expanded',opening);};
async function start(){controls();try{const response=await fetch('/api/config');if(!response.ok)throw new Error();const cfg=await response.json();state.samples=cfg.samples;state.limit=cfg.limit;$('sample-select').replaceChildren();for(const s of cfg.samples){const opt=document.createElement('option');opt.value=s.name;opt.textContent=`${s.name} — ${sizeLabel(s.size)}`;$('sample-select').append(opt);}sampleInfo();controls();}catch{problem('The local lab is unavailable. Reload the page or download the project to run it yourself.');}}
start();
