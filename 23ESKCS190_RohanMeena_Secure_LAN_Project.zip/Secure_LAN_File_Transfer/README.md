# Secure LAN File Transfer using AES & Socket Programming

**Syllabus mini project · Rohan Meena · 23ESKCS190 · Cyber Security Lab (7CS4-22)**

Send a file from an authenticated client to a receiver over TCP. **The sender encrypts the file before `sendall`; the receiver verifies the AES-GCM tag before it opens an output file.** The receiver returns a receipt after publication. The sender checks the SHA-256 in that receipt against its input.

## 1. First run: one computer

Use Python **3.11 or newer** with TLS 1.3 support, and a local filesystem that supports hard links (for example, ext4 or NTFS). The project was tested on Linux with CPython 3.13. Extract the ZIP and open a terminal **inside `Secure_LAN_File_Transfer`**, where `requirements.txt` is located. The only third-party package is `cryptography`.

```text
python -m venv .venv
```

Activate the environment with `. .venv/bin/activate` on Linux/macOS, or `.venv\Scripts\activate.bat` in Windows Command Prompt. If PowerShell activation is restricted, run the commands below with `.\.venv\Scripts\python.exe` in place of `python`; no policy change is needed. On systems with no `python` alias, use `python3` or the Windows `py` launcher to create the environment.

```text
python -m pip install -r requirements.txt
python demo.py
```

**Expected:** `VERIFIED`, the same source/stored SHA-256, and a real file under `demo-output/<transfer-id>-notes.txt`. The bundled `notes.txt` is 66 bytes; the file envelope is 94 bytes (66 + 12-byte nonce + 16-byte tag). Try `python demo.py examples/pattern.bin` for a binary transfer. The CLI demo uses genuine loopback sockets, not a file-copy shortcut. It keeps the recovered file, but removes the temporary CA, key and credentials when it exits.

### Browser workspace (optional)

```text
python studio.py
```

Open **http://127.0.0.1:8080**. Pick a sample or your own non-sensitive file, click **Send securely**, inspect the digest/envelope, and **Save received copy**. **Test denied login** exercises a real wrong password; no file key is issued and its isolated inbox must remain empty. Protocol and LAN setup tabs explain the two deployment paths. Press Ctrl+C to stop; use `--port 8081` if the UI port is already occupied. No Node.js, frontend build or external service is required.

The browser is a control panel: it uploads selected bytes to the Python sender. The Python sender and receiver communicate over real TLS/TCP loopback sockets using the same modules as the two-computer deployment. Each web request gets its own temporary inbox; verified bytes are read back from the receiver's actual file, returned only with that response, then removed from the demo inbox. The demo account `rohan` has a random password per studio launch, not a shared default password. Keep this UI on localhost for personal use. For private files or a proper two-device transfer use the standalone client on your own computer.

## 2. Real transfer: two computers on a private LAN

Install the project and dependency on both machines. In the commands below **192.168.1.20 is an example**: replace it on both sides with the receiver's own private IPv4 address. Use `ipconfig` on Windows or `ip addr` on Linux to read the receiver's address. Only run the receiver on a network you are authorised to use.

### Receiver (computer A)

```text
python pki.py lab --name receiver.lan
python accounts.py lab/accounts.json rohan
python server.py --bind 192.168.1.20 --port 9443
```

1. The first command creates a seven-day lab server certificate, its private key and the public CA certificate. Run it once in a new directory; it refuses to overwrite existing key material.
2. Enrol `rohan` with a passphrase of 12–256 UTF-8 bytes. The enrolment prompt asks twice; only a salted PBKDF2 verifier is stored. Rerun enrolment to change a password, then restart the receiver to reload its records.
3. Leave the receiver running. Restrict its firewall rule for TCP 9443 to the authorised private LAN or sender. Do not expose this lab service to the Internet.
4. Provision the sender with **only `lab/ca.pem`** via a trusted route. Verify its SHA-256 fingerprint out of band, e.g. compare `openssl x509 -in lab/ca.pem -noout -fingerprint -sha256` on both hosts. Do not copy `server.key` or `accounts.json` to the sender. Keep the receiver inbox and credentials in a private user-owned directory.

### Sender (computer B)

Make a `lab` folder in the extracted sender project and place that trusted `ca.pem` inside it. **Do not generate a separate CA on the sender.** Then run:

```text
python client.py examples/notes.txt --user rohan --host 192.168.1.20 --port 9443 --name receiver.lan --ca lab/ca.pem
```

Enter the enrolled password. The program connects to the given IP but independently checks the certificate name `receiver.lan`; no DNS change is required. On success it prints the unique stored name and checked SHA-256 digest. Look in `received/` on computer A for `<transfer-id>-notes.txt`. Use any file up to **8 MiB**, including empty files. The transmitted basename must start with a letter/digit and contain only ASCII letters, digits, `_`, `-` or `.` (80 bytes maximum). Preserve a local name with spaces by specifying a different transmitted name, e.g. `python client.py "Lab Notes.pdf" --as-name Lab_Notes.pdf --user rohan --host 192.168.1.20`.

For a manual test on one machine, use both terminals on the same host and replace `192.168.1.20` with `127.0.0.1`. Default port: **9443 for the TCP receiver**, **8080 for the optional browser UI**.

## 3. Protocol at a glance

| Step | Sender | Receiver |
|---|---|---|
| 1. Verify peer | Validate the expected name and trusted CA in a TLS 1.3-capable context. | Present server certificate. |
| 2. Authenticate | Submit username and password inside TLS. | Compare salted PBKDF2-HMAC-SHA256 (600,000 rounds) verifier; deny or issue a fresh 16-byte transfer ID and a 32-byte AES key inside TLS. |
| 3. Seal + send | AES-256-GCM with a fresh 12-byte nonce. Send basename and sealed record as length-prefixed frames. | Bound lengths and read each record completely; reject an invalid name, oversized body or premature EOF. |
| 4. Commit + acknowledge | Check `STORED` + SHA-256 against the source bytes. | Verify the GCM tag, flush verified plaintext to a same-directory temporary file, publish via a non-overwriting hard link, then send the receipt. |

**File envelope:** `nonce [12] | ciphertext [n] | tag [16]`. The file frame adds a four-byte big-endian length. The application record is already encrypted before being passed to the transport. The GCM associated data binds the protocol version, transfer ID, user and filename. TLS protects login, key delivery, filename, envelope and receipt in transit. SHA-256 is a content equality check, **not** the authentication mechanism. The output **is plaintext by design**; protect it with OS permissions. A lost receipt makes delivery uncertain: an automatic retry could create a second copy.

## 4. Tests and demonstration checklist

```text
python -m unittest discover -s tests -v
python run_lab.py --json results.json
```

The eight fast unit tests cover split reads, bounded allocation, name validation, binary/empty file handling, authenticated metadata and non-overwriting publication. The independent end-to-end suite uses only fresh test keys, synthetic files and its own loopback server. It checks:

- exact text, binary and empty-file round trips;
- rejection of a wrong password, modified tag, truncated frame, oversized frame and wrong TLS hostname;
- no new output file in any of the five rejected cases;
- a short-read probe and 20 additional round trips (5 each at 4 KiB, 64 KiB, 1 MiB and 8 MiB).

`sample_run.txt` is the example run quoted in the companion report. Your timings, transfer IDs, keys and nonces will differ. Loopback timings do not measure Wi-Fi or Ethernet speed.

**Suggested viva:** send `examples/notes.txt`, compare the source and stored digests, inspect the +28-byte envelope, demonstrate a denied login, then repeat with a second LAN computer. Source code and tests do not require the browser UI.

## 5. Files

| Files | Purpose |
|---|---|
| `server.py`, `client.py` | Independent receiver and sender processes for a LAN. |
| `protocol.py` | Bounded TCP framing, AES-GCM seal/open and associated data. |
| `accounts.py`, `pki.py` | Local account enrolment, temporary lab CA and server certificate. |
| `demo.py`, `local_session.py` | One-command real transfer; adapter for temporary local endpoints. |
| `studio.py`, `web/` | Optional browser workspace; plain HTML, CSS, JavaScript and a Python HTTP server. |
| `examples/` | Three non-sensitive sample inputs. |
| `tests/test_core.py`, `run_lab.py`, `sample_run.txt` | Unit checks, socket integration suite, reference console output. |
| `bundle.py` | Exports only allowlisted source and examples; never ships private keys or stored files. |

## 6. Common problems and limitations

| Symptom | What to check |
|---|---|
| `No module named cryptography` | Install `requirements.txt` using the same Python interpreter that runs the scripts. |
| Connection refused / timed out | Receiver process, assigned LAN IP, TCP port, reachability on the authorised network, and private firewall rule. Do not disable the firewall. |
| Certificate verification failed | Correct trusted CA, `--name receiver.lan`, system clocks and seven-day validity. Renew using a fresh lab directory and securely distribute the new public CA; do not disable verification. |
| Login denied | Enrolled username/passphrase, matching accounts file, and server restart after enrolment. |
| File cannot be stored | Keep the private inbox on a local volume supporting hard links (not FAT/exFAT). Check disk space and permissions. |

This is a bounded teaching implementation: one upload per login, one connection at a time in the standalone receiver, whole-file buffering, and no resumable uploads, lockout/rate limiting, at-rest encryption or exactly-once delivery. It assumes trusted endpoints and a securely provisioned CA. Use managed tools for a production file service.
