"""One-command real socket transfer with disposable local credentials."""
import argparse
from pathlib import Path
from local_session import DemoLab
from protocol import MAX_FILE, ProtocolError

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Send a file through a local authenticated receiver')
    p.add_argument('file', nargs='?', type=Path,
                   default=Path(__file__).parent / 'examples' / 'notes.txt')
    p.add_argument('--out', type=Path, default=Path('demo-output'), help='private receiver inbox')
    a = p.parse_args()
    try:
        with a.file.open('rb') as f:
            data = f.read(MAX_FILE + 1)
        with DemoLab() as lab:
            result = lab.transfer(a.file.name, data, keep_inbox=a.out).receipt
        print('VERIFIED  |  Secure LAN File Transfer')
        print('Channel:     real loopback TCP socket /', result['tls'])
        print('Session:     authenticated user rohan; one-use AES-256-GCM key')
        print('File:       ', result['name'], f"({result['plain_bytes']} bytes)")
        print('Envelope:   ', result['envelope_bytes'], 'bytes (12-byte nonce + ciphertext + 16-byte tag)')
        print('Source hash:', result['sha256'])
        print('Stored hash:', result['receiver_sha256'])
        print('Saved to:   ', (a.out / result['saved_name']).resolve())
    except (OSError, ValueError, EOFError, RuntimeError) as err:
        p.exit(1, 'Demo failed: ' + str(err) + '\n')
