"""Build a source-only distribution; generated keys, files and logs are never globbed."""
import io
from pathlib import Path
import zipfile
ROOT = Path(__file__).resolve().parent
PROJECT_ZIP = '23ESKCS190_RohanMeena_Secure_LAN_Project.zip'
FILES = ('README.md','requirements.txt','protocol.py','accounts.py','pki.py','server.py',
         'client.py','local_session.py','demo.py','studio.py','bundle.py','run_lab.py',
         'sample_run.txt','tests/test_core.py','examples/notes.txt','examples/readings.csv',
         'examples/pattern.bin','web/index.html','web/studio.css','web/studio.js','web/mark.svg')

def source_zip():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as out:
        for name in FILES:
            out.write(ROOT/name,'Secure_LAN_File_Transfer/'+name)
    return buffer.getvalue()

if __name__=='__main__':
    out=ROOT.parent/PROJECT_ZIP
    out.write_bytes(source_zip()); print(out)
