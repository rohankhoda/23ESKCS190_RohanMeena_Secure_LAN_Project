"""Run only against this process's own loopback receiver and temporary data."""
import argparse
import contextlib
import hashlib
import json
import os
import platform
import socket
import ssl
import statistics
import struct
import sys
import tempfile
import threading
import time
from pathlib import Path
import cryptography
from accounts import new_record
from client import connect, login, upload
from pki import issue
from protocol import MAX_FILE, BOX_OVERHEAD, get_frame, send_frame, seal
from server import handle, server_context

SAMPLE = b'LAN transfer lab\nFile: notes.txt\nOwner: Rohan Meena\nStatus: ready\n'
USER = b'rohan'

def check(test, message):
    if not test:
        raise AssertionError(message)

def short_read_probe():
    """Cap each payload recv at seven bytes. These are reads, not packet boundaries."""
    body = bytes(range(31))
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0)); listener.listen(1)
        with socket.create_connection(listener.getsockname(),timeout=8) as tx:
            rx,_ = listener.accept()
            with rx:
                rx.settimeout(8)
                send_frame(tx,body)
                chunks=[]
                class Capped:
                    def recv(self,n):
                        data = rx.recv(min(n,7)); chunks.append(len(data)); return data
                recovered = get_frame(Capped(),64)
                check(recovered==body,'short reads changed payload')
                return chunks[1:]

def run():
    report={'tests':[], 'bench':[]}
    with tempfile.TemporaryDirectory() as root:
        root=Path(root); issue(root); inbox=root/'received'; inbox.mkdir(mode=0o700)
        ctx=server_context(root/'server.pem',root/'server.key')
        pw=os.urandom(24).hex().encode(); db={USER:new_record(pw)}; dummy=new_record(os.urandom(32))
        @contextlib.contextmanager
        def session(dns='receiver.lan'):
            with socket.socket() as listener:
                listener.bind(('127.0.0.1',0));listener.listen(1);listener.settimeout(8)
                port=listener.getsockname()[1]; status=[]
                def work():
                    c,_=listener.accept(); status.append(handle(c,ctx,db,dummy,inbox))
                thread=threading.Thread(target=work);thread.start()
                try:
                    with connect('127.0.0.1',port,root/'ca.pem',dns) as sock:
                        yield sock,status
                finally:
                    thread.join(12);check(not thread.is_alive(),'server did not stop')
        def success(name,data):
            before=set(inbox.iterdir())
            with session() as (sock,st):
                start=time.perf_counter_ns(); ticket,key=login(sock,USER,pw)
                ready=time.perf_counter_ns()
                box,receipt=upload(sock,key,ticket,USER,name,data)
                end=time.perf_counter_ns(); tls=sock.version()
            path=inbox/(ticket.hex()+'-'+name.decode())
            recovered=path.read_bytes()
            check(st==['STORED'] and set(inbox.iterdir())-before=={path},'unexpected publication')
            check(recovered==data and receipt[6:]==hashlib.sha256(data).digest(),'content mismatch')
            return {'n':len(data),'box':len(box),'prefix':box[:12].hex(), 'ct':box[12:-16][:24].hex(),
                    'tag':box[-16:].hex(),'digest':receipt[6:].hex(),'tls':tls,
                    'login_ms':(ready-start)/1e6,'upload_ms':(end-ready)/1e6}
        def passed(label,detail):
            report['tests'].append({'label':label,'detail':detail})
            print('PASS  '+label,flush=True)
        note=success(b'notes.txt',SAMPLE);note['text']=SAMPLE.decode();report['sample']=note
        passed('Text file round trip','bytes + receipt match')
        success(b'binary.bin',bytes(range(256))*16)
        passed('Binary file round trip','4096 bytes match')
        empty=success(b'empty.bin',b'');check(empty['box']==28,'empty box overhead')
        passed('Empty file','zero bytes committed')
        snapshot=set(inbox.iterdir())
        with session() as (sock,st):
            try: login(sock,USER,b'not-the-test-password')
            except PermissionError: pass
            else: raise AssertionError('login should fail')
        check(st==['DENIED'] and set(inbox.iterdir())==snapshot,'bad login wrote a file')
        passed('Wrong password','DENIED, no new file')
        with session() as (sock,st):
            t,k=login(sock,USER,pw);bad=bytearray(seal(k,t,USER,b'notes.txt',SAMPLE));bad[-1]^=1
            send_frame(sock,b'notes.txt');send_frame(sock,bytes(bad))
            check(get_frame(sock,38)==b'REJECTED','modified tag accepted')
        check(st==['InvalidTag'] and set(inbox.iterdir())==snapshot,'bad tag wrote a file')
        passed('Changed GCM tag','REJECTED, no new file')
        with session() as (sock,st):
            t,k=login(sock,USER,pw);box=seal(k,t,USER,b'notes.txt',SAMPLE)
            send_frame(sock,b'notes.txt');sock.sendall(struct.pack('!I',len(box))+box[:12])
        check(st==['INCOMPLETE'] and set(inbox.iterdir())==snapshot,'partial file published')
        passed('Incomplete file frame','EOF, no new file')
        with session() as (sock,st):
            t,k=login(sock,USER,pw);send_frame(sock,b'too-big.bin')
            sock.sendall(struct.pack('!I',MAX_FILE+BOX_OVERHEAD+1))
            check(get_frame(sock,38)==b'REJECTED','size check failed')
        check(st==['ProtocolError'] and set(inbox.iterdir())==snapshot,'oversize accepted')
        passed('Oversized file frame','REJECTED, no new file')
        try:
            with session('different.lan') as _: raise AssertionError('wrong TLS name accepted')
        except ssl.SSLCertVerificationError: pass
        check(set(inbox.iterdir())==snapshot,'bad name wrote a file')
        passed('TLS hostname mismatch','certificate rejected')
        print(f"\n{len(report['tests'])}/8 functional checks passed.")
        chunks=short_read_probe();report['reads']=chunks
        print('31-byte read probe:', ' + '.join(map(str,chunks)), 'bytes')
        print('Benchmark: 5 new sessions per file size.')
        for n in [4*1024,64*1024,1024*1024,8*1024*1024]:
            data=bytes(range(256))*(n//256)
            vals=[success(b'bench.bin',data) for _ in range(5)]
            row={'n':n,'box':vals[0]['box'],'login':[v['login_ms'] for v in vals],
                 'upload':[v['upload_ms'] for v in vals],'matches':len(vals)}
            report['bench'].append(row)
            print(f"{n:>8} B | median upload {statistics.median(row['upload']):7.2f} ms | 5/5 exact")
        report['env']={'python':platform.python_version(),'ssl':ssl.OPENSSL_VERSION,
                       'cryptography':cryptography.__version__,'os':platform.system(),'arch':platform.machine(),
                       'kernel':platform.release()}
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--json',type=Path);a=p.parse_args()
    print('Secure LAN File Transfer | loopback test runner\n')
    results=run()
    if a.json: a.json.write_text(json.dumps(results,indent=2)+'\n')
