"""Local demonstration UI. File traffic still traverses the project's TLS/TCP receiver."""
import argparse
import base64
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from bundle import source_zip, PROJECT_ZIP
from local_session import DemoLab
from protocol import MAX_FILE, ProtocolError, valid_name

ROOT = Path(__file__).resolve().parent
SAMPLES = {'notes.txt':'A four-line lab note', 'readings.csv':'25 synthetic sensor readings',
           'pattern.bin':'All 256 byte values, repeated'}
PAGES = {'/':('index.html','text/html; charset=utf-8'),
         '/studio.css':('studio.css','text/css; charset=utf-8'),
         '/studio.js':('studio.js','text/javascript; charset=utf-8'),
         '/mark.svg':('mark.svg','image/svg+xml'), '/favicon.ico':('mark.svg','image/svg+xml')}

class Handler(BaseHTTPRequestHandler):
    server_version = 'Lanpost/1.0'
    def setup(self):
        super().setup(); self.connection.settimeout(15)

    def log_message(self, fmt, *args):
        # No filenames, file contents, account secrets or runtime keys in HTTP logs.
        return

    def reply(self, status, body, content_type, *, download=None):
        self.send_response(status)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'")
        if download: self.send_header('Content-Disposition',f'attachment; filename="{download}"')
        self.end_headers()
        if self.command != 'HEAD':
            try: self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError): pass

    def as_json(self,status,obj):
        self.reply(status,json.dumps(obj,separators=(',',':')).encode(),'application/json; charset=utf-8')

    def do_HEAD(self): self.do_GET()

    def do_GET(self):
        path=urlsplit(self.path).path
        if path in PAGES:
            name, typ=PAGES[path]
            self.reply(200,(ROOT/'web'/name).read_bytes(),typ)
        elif path=='/api/config':
            self.as_json(200,{'limit':MAX_FILE,'samples':[{'name':name,'description':v,
                'size':(ROOT/'examples'/name).stat().st_size} for name,v in SAMPLES.items()]})
        elif path=='/project.zip':
            self.reply(200,self.server.package,'application/zip',download=PROJECT_ZIP)
        else:
            self.as_json(404,{'error':'That page was not found.'})

    def do_POST(self):
        path=urlsplit(self.path).path
        if path not in ('/api/transfer','/api/deny'):
            return self.as_json(404,{'error':'Unknown operation.'})
        # This UI issues same-origin fetches. No CORS grants, remote host controls or filesystem URLs.
        if self.headers.get('X-Lanpost-Action')!='transfer-v1' or self.headers.get('Sec-Fetch-Site')=='cross-site':
            return self.as_json(403,{'error':'Open the transfer workspace to run this demo.'})
        if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length',[]))>1:
            return self.as_json(400,{'error':'A single bounded body is required.'})
        length=self.headers.get('Content-Length','0')
        if not re.fullmatch(r'[0-9]{1,10}',length):
            return self.as_json(400,{'error':'Invalid content length.'})
        size=int(length)
        if size>MAX_FILE:
            return self.as_json(413,{'error':'Maximum file size is 8 MiB.'})
        if not self.server.work_slots.acquire(blocking=False):
            return self.as_json(429,{'error':'The lab is busy. Please try again in a moment.'})
        try:
            if path=='/api/deny':
                if size: raise ValueError('This check does not accept a file.')
                run=self.server.lab.transfer('notes.txt',b'',deny=True)
            else:
                sample=self.headers.get('X-Lanpost-Sample')
                if sample is not None:
                    if sample not in SAMPLES or size: raise ValueError('Unknown sample or unexpected body.')
                    name=sample;data=(ROOT/'examples'/sample).read_bytes()
                else:
                    name=self.headers.get('X-Lanpost-Name','')
                    valid_name(name.encode('ascii'))
                    if self.headers.get('Content-Length') is None:
                        raise ValueError('Missing file length.')
                    data=self.rfile.read(size)
                    if len(data)!=size: raise ValueError('The browser upload was incomplete.')
                run=self.server.lab.transfer(name,data)
                run.receipt['recovered_b64']=base64.b64encode(run.recovered).decode('ascii')
            self.as_json(200,run.receipt)
        except (ValueError,ProtocolError,UnicodeError) as err:
            self.as_json(400,{'error':str(err)})
        except (OSError,EOFError,RuntimeError):
            self.as_json(500,{'error':'Transfer not confirmed. Retry with the included sample, or run the CLI tests.'})
        finally:
            self.server.work_slots.release()

class StudioServer(ThreadingHTTPServer):
    # Finish admitted requests before removing the temporary certificate directory on shutdown.
    daemon_threads = False
    allow_reuse_address = True

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Run the secure LAN transfer demo in a browser')
    p.add_argument('--bind',default='127.0.0.1',help='UI address; leave on loopback for personal use')
    p.add_argument('--port',default=8080,type=int)
    a=p.parse_args()
    if not 1<=a.port<=65535: p.error('port must be 1–65535')
    try:
        with DemoLab() as lab, StudioServer((a.bind,a.port),Handler) as http:
            http.lab=lab;http.work_slots=threading.BoundedSemaphore(2);http.package=source_zip()
            print(f'Lanpost transfer workspace: http://{a.bind}:{a.port}',flush=True)
            print('The file receiver is loopback-only. Press Ctrl+C to stop.',flush=True)
            try:http.serve_forever()
            except KeyboardInterrupt:pass
    except OSError as err:
        p.exit(1,'Could not start the local workspace: '+str(err)+'\n')
