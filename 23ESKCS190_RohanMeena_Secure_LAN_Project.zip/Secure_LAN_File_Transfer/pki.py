"""Create a temporary lab trust anchor and TLS certificate. Never publish the key."""
import argparse
import datetime as dt
import os
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID

def issue(folder, dns_name='receiver.lan'):
    folder = Path(folder)
    folder.mkdir(parents=True, mode=0o700, exist_ok=True)
    ca_key, key = [ec.generate_private_key(ec.SECP256R1()) for _ in range(2)]
    now = dt.datetime.now(dt.timezone.utc)
    subject = lambda name: x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,name)])
    def build(name, issuer, public, is_ca):
        return (x509.CertificateBuilder().subject_name(subject(name)).issuer_name(subject(issuer))
                .public_key(public).serial_number(x509.random_serial_number())
                .not_valid_before(now-dt.timedelta(minutes=5)).not_valid_after(now+dt.timedelta(days=7))
                .add_extension(x509.BasicConstraints(ca=is_ca,path_length=0 if is_ca else None),critical=True)
                .add_extension(x509.SubjectKeyIdentifier.from_public_key(public),critical=False)
                .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()),critical=False)
                .add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,
                    data_encipherment=False,key_agreement=False,key_cert_sign=is_ca,crl_sign=is_ca,
                    encipher_only=False,decipher_only=False),critical=True))
    ca = build('SLF Lab CA','SLF Lab CA',ca_key.public_key(),True).sign(ca_key,hashes.SHA256())
    cert = (build(dns_name,'SLF Lab CA',key.public_key(),False)
            .add_extension(x509.SubjectAlternativeName([x509.DNSName(dns_name)]),critical=False)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),critical=False)
            .sign(ca_key,hashes.SHA256()))
    # Refuse to overwrite existing credentials.
    for name, content, mode in [
        ('server.key',key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,
                                        serialization.NoEncryption()),0o600),
        ('server.pem',cert.public_bytes(serialization.Encoding.PEM),0o644),
        ('ca.pem',ca.public_bytes(serialization.Encoding.PEM),0o644)]:
        fd = os.open(folder/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb') as f: f.write(content)

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('folder',type=Path);p.add_argument('--name',default='receiver.lan')
    a=p.parse_args(); issue(a.folder,a.name)
    print('Lab certificate issued for',a.name)
