"""Local account enrolment: python accounts.py accounts.json rohan"""
import argparse
import getpass
import hashlib
import hmac
import json
import os
import re
import tempfile
from pathlib import Path

ROUNDS = 600_000

def verifier(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password, salt, ROUNDS, dklen=32)

def new_record(password):
    salt = os.urandom(16)
    return salt, verifier(password, salt)

def authenticate(records, dummy, user, password):
    record = records.get(user)
    salt, expected = record if record is not None else dummy
    same = hmac.compare_digest(verifier(password, salt), expected)
    return record is not None and same

def load(path):
    raw = json.loads(Path(path).read_text())
    return {k.encode('ascii'): tuple(bytes.fromhex(x) for x in v) for k,v in raw.items()}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create or update one test account locally')
    parser.add_argument('file', type=Path)
    parser.add_argument('user')
    a = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', a.user):
        parser.error('expected an ASCII username of 1 to 64 characters')
    pw = getpass.getpass('New passphrase: ').encode('utf-8')
    if not 12 <= len(pw) <= 256:
        parser.error('choose a passphrase of 12 to 256 UTF-8 bytes')
    if not hmac.compare_digest(pw, getpass.getpass('Confirm passphrase: ').encode('utf-8')):
        parser.error('passphrases do not match')
    a.file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    raw = json.loads(a.file.read_text()) if a.file.exists() else {}
    raw[a.user] = [x.hex() for x in new_record(pw)]
    with tempfile.NamedTemporaryFile(mode='w', dir=a.file.parent, delete=False) as tmp:
        json.dump(raw, tmp)
    os.replace(tmp.name, a.file)
    print('Account enrolled:', a.user)
