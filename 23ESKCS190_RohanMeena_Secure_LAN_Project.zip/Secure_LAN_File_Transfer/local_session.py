"""Adapters for the one-command demo. No simulated encryption or network calls.

Each request gets a private inbox and a real short-lived TCP listener bound only
on loopback. It runs the same handle(), connect(), login() and upload() as the
standalone programs. The web interface cannot select an address or remote port.
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import nullcontext
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import socket
from tempfile import TemporaryDirectory
from time import perf_counter

from accounts import new_record
from client import connect, login, upload
from pki import issue
from protocol import MAX_FILE, ProtocolError, valid_name
from server import handle, server_context


@dataclass
class Run:
    receipt: dict
    recovered: bytes


class DemoLab:
    def __init__(self):
        self.root = TemporaryDirectory(prefix='lanpost-')
        self.base = Path(self.root.name)
        issue(self.base)
        self.ca = self.base / 'ca.pem'
        self.ctx = server_context(self.base / 'server.pem', self.base / 'server.key')
        self.user = b'rohan'
        self.password = os.urandom(24).hex().encode('ascii')
        self.accounts = {self.user: new_record(self.password)}
        self.dummy = new_record(os.urandom(24))

    def close(self):
        self.root.cleanup()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def transfer(self, name, plain, *, deny=False, keep_inbox=None):
        name_b = name.encode('ascii')
        valid_name(name_b)
        if len(plain) > MAX_FILE:
            raise ProtocolError('The file exceeds 8 MiB.')
        if deny and keep_inbox is not None:
            raise ValueError('Login checks must use a fresh private inbox.')
        inbox_context = (TemporaryDirectory(prefix='inbox-', dir=self.base)
                         if keep_inbox is None else nullcontext(keep_inbox))
        with inbox_context as folder, socket.socket() as listener:
            inbox = Path(folder)
            inbox.mkdir(parents=True, mode=0o700, exist_ok=True)
            listener.bind(('127.0.0.1', 0))
            listener.listen(1)
            listener.settimeout(8)
            def receive_one():
                conn, _ = listener.accept()
                return handle(conn, self.ctx, self.accounts, self.dummy, inbox)
            with ThreadPoolExecutor(max_workers=1) as worker:
                outcome = worker.submit(receive_one)
                t0 = perf_counter()
                with connect(*listener.getsockname(), self.ca, 'receiver.lan') as sock:
                    tls = sock.version()
                    t1 = perf_counter()
                    if deny:
                        try:
                            login(sock, self.user, b'intentionally-not-the-credential')
                        except PermissionError:
                            pass
                        else:
                            raise RuntimeError('A negative login check unexpectedly succeeded.')
                    else:
                        ticket, key = login(sock, self.user, self.password)
                        ready = perf_counter()
                        envelope, receipt = upload(sock, key, ticket, self.user, name_b, plain)
                elapsed = perf_counter() - t0
                status = outcome.result(timeout=10)
            if deny:
                if status != 'DENIED' or any(inbox.iterdir()):
                    raise RuntimeError('The rejection check failed.')
                return Run({'status':'denied', 'tls':tls, 'stored_files':0,
                            'elapsed_ms':round(elapsed*1000,2)}, b'')
            if status != 'STORED':
                raise RuntimeError('The receiver did not confirm storage.')
            output = inbox / (ticket.hex() + '-' + name)
            recovered = output.read_bytes()
            digest, stored = hashlib.sha256(plain).hexdigest(), hashlib.sha256(recovered).hexdigest()
            if recovered != plain or receipt[6:].hex() != digest or stored != digest:
                raise RuntimeError('The saved file did not match the input.')
            return Run({'status':'verified','name':name,'ticket':ticket.hex(),
                        'saved_name':output.name, 'plain_bytes':len(plain),
                        'envelope_bytes':len(envelope), 'sha256':digest,
                        'receiver_sha256':stored, 'receipt_sha256':receipt[6:].hex(),
                        'tls':tls, 'nonce':envelope[:12].hex(),'tag':envelope[-16:].hex(),
                        'cipher_preview':envelope[12:-16][:24].hex(),
                        'elapsed_ms':round(elapsed*1000,2),
                        'login_ms':round((ready-t1)*1000,2)}, recovered)
