"""Single-upload TLS receiver. A private inbox must be owned by the service account."""
import argparse
import hashlib
import os
import socket
import ssl
import tempfile
from pathlib import Path
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from accounts import authenticate, load, new_record
from protocol import MAX_FILE, BOX_OVERHEAD, get_frame, send_frame, unseal, valid_name, ProtocolError

def publish(inbox, ticket, name, plain):
    dest = inbox / (ticket.hex() + '-' + name.decode('ascii'))
    path = None
    try:
        with tempfile.NamedTemporaryFile(dir=inbox, delete=False) as f:
            path = f.name
            f.write(plain)
            f.flush()
            os.fsync(f.fileno())
        os.link(path, dest)   # same filesystem; fails if destination exists
    finally:
        if path is not None:
            os.unlink(path)
    return dest

def receive(sock, accounts, dummy, inbox):
    user = get_frame(sock, 64)
    password = get_frame(sock, 256)
    if not authenticate(accounts, dummy, user, password):
        send_frame(sock, b'DENIED')
        return 'DENIED'
    ticket = os.urandom(16)
    key = AESGCM.generate_key(bit_length=256)
    send_frame(sock, b'READY')
    send_frame(sock, ticket + key)
    name = get_frame(sock, 80)
    valid_name(name)
    box = get_frame(sock, MAX_FILE + BOX_OVERHEAD)
    plain = unseal(key, ticket, user, name, box)
    publish(inbox, ticket, name, plain)
    send_frame(sock, b'STORED' + hashlib.sha256(plain).digest())
    return 'STORED'

def server_context(cert, key):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.load_cert_chain(cert, key)
    return ctx

def handle(raw, ctx, accounts, dummy, inbox):
    raw.settimeout(8)
    raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    try:
        with ctx.wrap_socket(raw, server_side=True) as conn:
            try:
                return receive(conn, accounts, dummy, inbox)
            except (InvalidTag, ProtocolError) as err:
                send_frame(conn, b'REJECTED')
                return type(err).__name__
            except EOFError:
                return 'INCOMPLETE'
    except (ssl.SSLError, OSError) as err:
        return type(err).__name__
    finally:
        raw.close()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--bind', default='127.0.0.1')
    p.add_argument('--port', type=int, default=9443)
    p.add_argument('--cert', default='lab/server.pem')
    p.add_argument('--key', default='lab/server.key')
    p.add_argument('--accounts', default='lab/accounts.json')
    p.add_argument('--inbox', default='received', type=Path)
    a = p.parse_args()
    a.inbox.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        ctx = server_context(a.cert, a.key)
        db, dummy = load(a.accounts), new_record(os.urandom(32))
    except (OSError, ValueError) as err:
        p.exit(1, 'Receiver setup failed: ' + str(err) + '\nSee the two-computer setup in README.md.\n')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        if not 1 <= a.port <= 65535:
            p.error('port must be in the range 1 to 65535')
        try:
            listener.bind((a.bind, a.port))
        except OSError as err:
            p.exit(1, 'Cannot listen on that address/port: ' + str(err) + '\n')
        listener.listen(4)
        print('Listening on', listener.getsockname(), flush=True)
        print('Private inbox:', a.inbox.resolve(), '| Press Ctrl+C to stop.', flush=True)
        try:
            while True:
                conn, _ = listener.accept()
                print(handle(conn, ctx, db, dummy, a.inbox), flush=True)
        except KeyboardInterrupt:
            pass
