"""Send one file using a verified TLS connection and a fresh AES-256-GCM key."""
import argparse
import getpass
import hashlib
import hmac
import socket
import re
import sys
import ssl
from pathlib import Path
from protocol import MAX_FILE, get_frame, send_frame, seal, valid_name, ProtocolError

def connect(host, port, ca, dns_name):
    ctx = ssl.create_default_context(cafile=str(ca))
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    raw = socket.create_connection((host, port), timeout=8)
    raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    try:
        return ctx.wrap_socket(raw, server_hostname=dns_name)
    except BaseException:
        raw.close()
        raise

def login(sock, user, password):
    if not (1 <= len(user) <= 64 and 1 <= len(password) <= 256):
        raise ProtocolError('invalid credential length')
    send_frame(sock, user)
    send_frame(sock, password)
    if get_frame(sock, 16) != b'READY':
        raise PermissionError('login denied')
    offer = get_frame(sock, 48)
    if len(offer) != 48:
        raise ProtocolError('invalid transfer offer')
    return offer[:16], offer[16:]

def upload(sock, key, ticket, user, name, plain):
    box = seal(key, ticket, user, name, plain)
    send_frame(sock, name)
    send_frame(sock, box)
    receipt = get_frame(sock, 38)
    expected = b'STORED' + hashlib.sha256(plain).digest()
    if not hmac.compare_digest(receipt, expected):
        raise ProtocolError('no matching storage receipt')
    return box, receipt

def main():
    p = argparse.ArgumentParser(description='Authenticated AES-GCM file sender')
    p.add_argument('file', type=Path, help='local file, up to 8 MiB')
    p.add_argument('--host', default='127.0.0.1', help='address of the authorised receiver')
    p.add_argument('--port', type=int, default=9443)
    p.add_argument('--name', default='receiver.lan', help='certified receiver hostname')
    p.add_argument('--ca', type=Path, default=Path('lab/ca.pem'))
    p.add_argument('--user', required=True)
    p.add_argument('--as-name', help='optional simple name for the received copy')
    a = p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', a.user):
        p.error('expected a 1–64 character ASCII username (letters, digits, _ or -)')
    if not 1 <= a.port <= 65535:
        p.error('port must be in the range 1 to 65535')
    try:
        name = (a.as_name or a.file.name).encode('ascii')
        valid_name(name)
        with a.file.open('rb') as f:
            plain = f.read(MAX_FILE + 1)
        if len(plain) > MAX_FILE:
            raise ProtocolError('8 MiB maximum')
        if not a.ca.is_file():
            raise FileNotFoundError('trusted CA file missing: ' + str(a.ca))
        user = a.user.encode('ascii')
        # Prompt before opening the socket: typing time is not network idle time.
        password = getpass.getpass('Password: ').encode('utf-8')
        with connect(a.host, a.port, a.ca, a.name) as sock:
            ticket, key = login(sock, user, password)
            _, receipt = upload(sock, key, ticket, user, name, plain)
            print('Transport:', sock.version(), '| File cipher: AES-256-GCM')
            print('Stored:', ticket.hex() + '-' + name.decode())
            print('Bytes:', len(plain))
            print('SHA-256:', receipt[6:].hex())
    except UnicodeEncodeError:
        p.exit(1, 'Use an ASCII filename; --as-name can give the copy a different name.\n')
    except (ssl.SSLError, OSError, ProtocolError, EOFError) as err:
        p.exit(1, 'Transfer not confirmed: ' + str(err) + '\n')

if __name__ == '__main__':
    main()
