"""Fast deterministic unit tests; run_lab.py separately exercises full TCP/TLS sessions."""
import io
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from cryptography.exceptions import InvalidTag
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from protocol import exact, get_frame, seal, unseal, valid_name, ProtocolError
from server import publish

class Fragmented:
    def __init__(self,data):self.stream=io.BytesIO(data)
    def recv(self,n):return self.stream.read(min(n,2))

class LabUnitTests(unittest.TestCase):
    def setUp(self):
        self.key=os.urandom(32);self.ticket=os.urandom(16)
        self.args=(self.key,self.ticket,b'rohan',b'notes.txt')
    def test_short_reads_include_split_header(self):
        self.assertEqual(get_frame(Fragmented(struct.pack('!I',5)+b'hello'),5),b'hello')
    def test_incomplete_frame(self):
        with self.assertRaises(EOFError):get_frame(Fragmented(struct.pack('!I',9)+b'x'),9)
    def test_length_rejected_before_body(self):
        with self.assertRaises(ProtocolError):get_frame(Fragmented(struct.pack('!I',65)),64)
    def test_filenames(self):
        for bad in [b'',b'../escape',b'/notes',b'two/notes',b'A'*81,b'file\x00']:
            with self.subTest(bad=bad),self.assertRaises(ProtocolError):valid_name(bad)
        valid_name(b'Lab_03-final.pdf')
    def test_binary_and_empty_envelopes(self):
        for data in (b'',bytes(range(256))):
            box=seal(*self.args,data)
            self.assertEqual(len(box),28+len(data));self.assertEqual(unseal(*self.args,box),data)
    def test_filename_is_authenticated(self):
        box=seal(*self.args,b'sample')
        with self.assertRaises(InvalidTag):unseal(*self.args[:3],b'other.txt',box)
    def test_ticket_and_user_are_authenticated(self):
        box=seal(*self.args,b'sample')
        for args in [(self.key,os.urandom(16),b'rohan',b'notes.txt'),(self.key,self.ticket,b'other',b'notes.txt')]:
            with self.subTest(),self.assertRaises(InvalidTag):unseal(*args,box)
    def test_commit_preserves_existing_file(self):
        with tempfile.TemporaryDirectory() as t:
            inbox=Path(t);dest=publish(inbox,self.ticket,b'notes.txt',b'first')
            with self.assertRaises(FileExistsError):publish(inbox,self.ticket,b'notes.txt',b'new')
            self.assertEqual(dest.read_bytes(),b'first');self.assertEqual(list(inbox.iterdir()),[dest])

if __name__=='__main__':unittest.main()
